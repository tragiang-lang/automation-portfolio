# スタッフ カスタマイズガイド

## 重要: 2箇所を編集する必要があります

メニューと同様、スタッフ情報も現バージョンでは2箇所に分かれています。

```text
予約フォーム（/reservation）のスタッフ選択・カレンダー連携
  → Google Sheets の STAFF シートが正（authoritative source）

トップページの「スタッフ紹介」セクションの表示（役職・紹介文・写真）
  → config/demo-content.ts の STAFF 定数
```

## STAFFシート（予約フォーム側・必須）

対象: スプレッドシートの`STAFF`タブ。

| 列 | 内容 |
|---|---|
| `StaffID` | スタッフの一意なID（例: `ST001`） |
| `Name` | スタッフ名（予約フォームに表示される名前） |
| `Active` | `true`で予約フォームに表示、`false`で非表示 |
| `CalendarID` | このスタッフ専用のGoogleカレンダーID（空欄可） |
| `DisplayOrder` | 表示順（小さい順） |

### スタッフを追加する

新しい行に、他と重複しない`StaffID`、名前、`Active`=`true`、
必要であれば`CalendarID`、表示順を入力します。

### スタッフを削除する（非表示にする）

行を削除するのではなく、**`Active`列を`false`に変更する**ことを
推奨します。過去の予約データが`StaffID`を参照しているためです。

### 表示名を変更する

`Name`列を直接編集します。

### 有効/無効を切り替える

`Active`列を`true`/`false`で切り替えます。

### スタッフ・カレンダーの対応付け

`CalendarID`列にスタッフ専用のGoogleカレンダーIDを設定すると、その
スタッフの予約はそのカレンダーに登録されます。空欄の場合は、
`CONFIG`シートの`calendar.id`がフォールバックとして使われます。
カレンダーIDの調べ方は
[`../04_SETUP_GUIDE/CALENDAR_SETUP_JA.md`](../04_SETUP_GUIDE/CALENDAR_SETUP_JA.md)
を参照してください。

### 「指名なし（お任せ）」の挙動

`CONFIG`シートの`staff.anyAvailableOption`が`true`の場合、予約フォーム
に「指名なし（お任せ）」という選択肢が表示され、その時間帯に対応可能な
スタッフが自動的に案内されます。`features.staffSelection`（スタッフ
指名機能そのもの）を`false`にする場合は、`staff.anyAvailableOption`
も`false`にしておくことを推奨します（スタッフ指名自体を行わない設計と
整合させるためです）。

### 触ってはいけないもの

`StaffID`は一度使い始めたら変更しないでください。既存の予約データが
この値を参照しています。また、シートには社内向けの識別子以上の情報
（住所・連絡先など）を入力しないでください。

## demo-content.ts（トップページ表示側・任意）

対象: `01_WEB_TEMPLATE/salon-website/config/demo-content.ts` の
`STAFF`定数。役職・紹介文・写真はこちらで管理されています
（`STAFF`シートにはこれらの列がありません）。

```ts
{
  staffId: "ST001",
  name: "田中 あい",
  role: "店長 / ネイリスト",
  introduction: "繊細なアートと、丁寧なカウンセリングが得意です。",
  photoSrc: "/images/staff/staff-avatar-01.svg",
  photoAlt: "スタッフ 田中あいのイメージアイコン",
},
```

トップページの表示をSheetsの内容と一致させたい場合は、`name`を
Sheets側と同じ値に手動で合わせてください。`role`・`introduction`は
自由に文章を作成し、`photoSrc`/`photoAlt`の差し替えは
[`IMAGE_CUSTOMIZATION_JA.md`](IMAGE_CUSTOMIZATION_JA.md) を参照して
ください。

同梱のスタッフ画像は実在の人物ではなく、本テンプレート用に作成された
イラストです。実在しない人物の名前・プロフィールを、実在の人物の
写真と結びつけて公開しないようご注意ください。
