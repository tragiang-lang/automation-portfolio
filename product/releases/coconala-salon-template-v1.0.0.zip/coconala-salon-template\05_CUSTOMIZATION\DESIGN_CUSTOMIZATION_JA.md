# デザイン カスタマイズガイド

## 変更先の対比表

```text
アクセントカラーを変える     → app/globals.css の @theme inline ブロック
店舗情報を変える            → Google Sheets CONFIG シート
メニューを変える            → Google Sheets SERVICES シート
スタッフを変える            → Google Sheets STAFF シート
画像を変える                → public/images/
```

業務データ（店舗名・価格・スタッフ名など）を、下記のプレゼンテーション
用ファイルに直接書き込まないでください。表示が二重管理になり、
Google Sheets側を更新しても反映されなくなります。

## 配色

配色は `01_WEB_TEMPLATE/salon-website/app/globals.css` 内の
`@theme inline` ブロックにあるCSSカスタムプロパティで一括管理されて
います。コンポーネント側は`bg-accent`・`text-muted`のようなTailwind
ユーティリティクラス経由でこれらの値を参照しているため、色を変える
場合はこのブロック内の値を変更してください（コンポーネントファイルの
中を1つずつ探して直接色コードを書き換える必要はありません）。

## タイポグラフィ・余白・アニメーション

`01_WEB_TEMPLATE/salon-website/config/theme.ts` に、JavaScript側から
参照する数値トークンがまとまっています。

| トークン | 内容 | 値 |
|---|---|---|
| `SPACING_PX` | 余白の基準スケール（4px単位） | 4 / 8 / 12 / 16 / 24 / 32 / 48 / 64 / 96 / 128 |
| `BREAKPOINTS_PX` | レスポンシブのブレークポイント | tablet: 640 / desktop: 1024 / largeDesktop: 1440 |
| `MOTION_MS` | アニメーションの長さ（ミリ秒） | heroEnter: 400 / reveal: 300 / press: 150 / accordion: 200 |
| `CONTENT_MAX_WIDTH_PX` | 本文コンテンツの最大幅 | 1120 |

余白は基本的にTailwindの数値クラス（`p-4`、`gap-6`など）が上記の
スケールとそのまま対応しているため、コンポーネントのクラス名を直接
編集して調整してください。`theme.ts`は、`IntersectionObserver`の
margin指定など、生の数値がどうしても必要な一部の箇所からのみ参照
されています。

## レスポンシブ対応

`BREAKPOINTS_PX`のJS側の値と、`globals.css`で設定されている
Tailwindの`sm:`/`lg:`/`xl:`プレフィックスに対応するブレークポイントは
一致しています。レイアウトを調整する場合は、これらのプレフィックス
付きクラスを使ってください。

## セクション・ボタンなどのコンポーネント

各セクション（ヒーロー・コンセプト・メニュー・スタッフ・ギャラリー
など）は `components/sections/` 配下、フォーム・ボタンなどの共通部品は
`components/ui/` 配下にあります。見た目の調整はこれらのコンポーネント
内のTailwindクラスを編集してください。業務データ（メニュー名や価格
など）をこれらのファイルに直接書き込まないよう注意してください
（`config/demo-content.ts`または対応するGoogle Sheetsを編集してくだ
さい）。
