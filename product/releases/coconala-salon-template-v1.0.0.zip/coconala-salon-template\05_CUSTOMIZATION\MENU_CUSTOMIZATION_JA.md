# メニュー（サービス）カスタマイズガイド

## 重要: 2箇所を編集する必要があります

メニュー情報は、現バージョンでは次の2箇所に分かれています。

```text
予約フォーム（/reservation）のメニュー選択・料金・所要時間
  → Google Sheets の SERVICES シートが正（authoritative source）
  → ここを編集すれば予約フォームにすぐ反映される

トップページの「メニュー」セクションの表示（説明文・カテゴリ含む）
  → config/demo-content.ts の SERVICES 定数
  → ここを編集しないとトップページの表示は変わらない
```

**予約の受付・料金計算・所要時間の判定は、必ずSERVICESシートの値が
使われます。** Reactコンポーネント側に価格や所要時間を直接書き込む
必要はありませんし、書き込んでも予約ロジックには反映されません。
一方で、トップページの見た目を変えたい場合は`demo-content.ts`側も
忘れずに編集してください。

## SERVICESシート（予約フォーム側・必須）

対象: `03_GOOGLE_SHEETS/SHEET_SETUP_GUIDE_JA.md`で作成したスプレッド
シートの`SERVICES`タブ。

| 列 | 内容 |
|---|---|
| `ServiceID` | メニューの一意なID（例: `SV001`） |
| `Name` | メニュー名 |
| `DurationMinutes` | 所要時間（分） |
| `Price` | 価格（円、数値のみ） |
| `Active` | `true`で予約フォームに表示、`false`で非表示 |
| `StaffRequired` | `true`の場合、このメニューは担当スタッフの指名が必要 |
| `DisplayOrder` | 表示順（小さい順） |

### メニューを追加する

新しい行に、他と重複しない`ServiceID`（例: 既存が`SV001`〜`SV003`なら
`SV004`）、メニュー名、所要時間、価格、`Active`=`true`、
`StaffRequired`、表示順を入力します。

### メニューを削除する（非表示にする）

行を削除するのではなく、**`Active`列を`false`に変更する**ことを
推奨します。過去の予約データ（`RESERVATIONS`シート）が`ServiceID`を
参照して残っているため、行そのものを削除すると整合性が崩れる可能性が
あります。

### 名前・価格・所要時間を変更する

該当する列のセルを直接編集するだけです。

### 表示順を変更する

`DisplayOrder`列の数値を変更します。小さい順に予約フォームへ表示
されます。

### 触ってはいけないもの

`ServiceID`は一度使い始めたら変更しないでください。既存の予約データ
（`RESERVATIONS`シートの`ServiceID`列）がこの値を参照しています。

### 反映のタイミング

シートを保存すると、次回の予約フォーム表示（`getServices`呼び出し）
から即座に反映されます。再デプロイは不要です。

## demo-content.ts（トップページ表示側・任意）

対象: `01_WEB_TEMPLATE/salon-website/config/demo-content.ts` の
`SERVICES`定数。

トップページの「メニュー」セクションに表示される説明文・カテゴリ分けは
こちらで管理されています（`SERVICES`シートには`description`や
`category`に相当する列がありません）。

```ts
{
  serviceId: "SV001",
  name: "ジェルネイル（ワンカラー）",
  description: "指先に一色をまとわせる、もっとも定番の仕上がり。",
  category: "ジェルネイル",
  durationMinutes: 60,
  price: 6000,
},
```

トップページの表示をSheetsの内容と一致させたい場合は、この配列の
`name`/`durationMinutes`/`price`をSheets側と同じ値に手動で合わせて
編集してください。`description`・`category`はトップページ専用の項目
なので、自由に文章を作成してください。
