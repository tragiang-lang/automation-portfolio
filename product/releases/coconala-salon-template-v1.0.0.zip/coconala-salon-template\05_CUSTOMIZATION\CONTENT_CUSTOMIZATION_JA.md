# コンテンツ カスタマイズガイド

このテンプレートで変更できる内容は、大きく2種類に分かれます。

```text
業務データ（business data）
  → 店舗名・営業時間・メニュー・スタッフ・連絡先など
  → Google Sheets で編集する

プレゼンテーション/デザイン（presentation / design）
  → 配色・フォント・余白・レイアウトなど
  → ソースコード（app/globals.css, config/theme.ts など）で編集する
```

どのファイルを触ってよいか迷ったときは、「実際のお客様に見せる文言や
数字（店舗名・価格・営業時間など）を変えたいのか」「見た目のスタイル
（色・余白・アニメーションなど）を変えたいのか」で判断してください。
前者はGoogle Sheets、後者はソースコードです。

## 業務データ（Google Sheetsで編集）

| 変更したい内容 | 編集先 | 詳細ガイド |
|---|---|---|
| 店舗名・電話番号・メール・住所・営業時間・機能ON/OFF | `CONFIG`シート | [`../04_SETUP_GUIDE/CONFIG_SETUP_JA.md`](../04_SETUP_GUIDE/CONFIG_SETUP_JA.md) |
| 休業日 | `HOLIDAYS`シート | [`../04_SETUP_GUIDE/CONFIG_SETUP_JA.md`](../04_SETUP_GUIDE/CONFIG_SETUP_JA.md) |
| メニュー（施術内容・価格・所要時間） | `SERVICES`シート | [`MENU_CUSTOMIZATION_JA.md`](MENU_CUSTOMIZATION_JA.md) |
| スタッフ（名前・有効/無効・カレンダー） | `STAFF`シート | [`STAFF_CUSTOMIZATION_JA.md`](STAFF_CUSTOMIZATION_JA.md) |
| 画像（トップ画像・ギャラリー・スタッフアイコン） | `public/images/` フォルダ | [`IMAGE_CUSTOMIZATION_JA.md`](IMAGE_CUSTOMIZATION_JA.md) |

## プレゼンテーション/デザイン（ソースコードで編集）

| 変更したい内容 | 編集先 | 詳細ガイド |
|---|---|---|
| 配色・フォント・余白・アニメーション速度 | `app/globals.css` / `config/theme.ts` | [`DESIGN_CUSTOMIZATION_JA.md`](DESIGN_CUSTOMIZATION_JA.md) |

## `config/demo-content.ts` について（重要・2つのデータソースの違い）

`01_WEB_TEMPLATE/salon-website/config/demo-content.ts` には、フロント
エンド専用のデモ文言（キャッチコピー・FAQ・アクセス案内・ご来店の
流れ・サロンの特徴・ギャラリー画像リスト、そしてトップページの
メニュー/スタッフ紹介セクション表示用のデータ）が含まれています。

**店舗の基本情報（店舗名・電話番号・メール・住所・営業時間・機能
ON/OFF）は`CONFIG`シートが優先されます**（`getRuntimeConfig()`経由で
Sheetsの値が使われ、`GAS_WEBAPP_URL`未設定時のみ`demo-content.ts`の
値がフォールバックとして使われます）。

一方で、**トップページの「メニュー」「スタッフ」セクションの表示内容
（説明文・カテゴリ・スタッフの紹介文・写真）と、FAQ・アクセス案内・
ギャラリー・サロンの特徴・ご来店の流れは、現バージョンでは
`config/demo-content.ts`に直接書かれた内容がそのまま表示されます**。
`SERVICES`/`STAFF`シートを編集すると、`/reservation`の予約フォーム
（メニュー選択・スタッフ選択・空き時間チェック）にはすぐ反映されます
が、トップページの表示セクションには自動反映されません（トップページ
のこれらのセクションを`getServices`/`getStaff`から取得する形に統合
することは、今後のバージョンでの改善候補です）。

そのため、メニューやスタッフを変更する際は、**予約フォーム用に
`SERVICES`/`STAFF`シートを編集し、かつトップページの表示用に
`config/demo-content.ts`内の該当箇所も手動で合わせて編集する**、
という2箇所編集が必要になる点にご注意ください。詳しい手順は
[`MENU_CUSTOMIZATION_JA.md`](MENU_CUSTOMIZATION_JA.md) と
[`STAFF_CUSTOMIZATION_JA.md`](STAFF_CUSTOMIZATION_JA.md) を参照して
ください。

現在`demo-content.ts`に入っているデモ内容（すべて架空のデータです）:

- 店舗名: `凛`（Rin Nail & Eyelash）
- キャッチコピー: `静けさの中で、指先とまなざしを整える。`
- 電話番号: `03-1234-5678`
- メール: `info@rin-salon.example.com`
- 住所: `東京都中央区銀座1-2-3 銀座ビルディング5F`
- デモメニュー7件・デモスタッフ4名（田中あい・鈴木さくら・佐藤みなみ・
  山本ゆい）
- FAQ・アクセス案内・サロンの特徴・ご来店の流れ

編集する際は、`app/*/page.tsx`（ページの組み立て元）以外からこの
ファイルをインポートしないという既存の設計を保つようにしてください。
